
/**
*	Node in a state-space search
*   Must implement goalPredicate, getSuccessors, sameState, node_toString
*   node has parent slot now
*   Phil Green 2013 version
*   Heidi Christensen (heidi.christensen@sheffield.ac.uk) 2021 version
*/

import java.util.*;

public class SearchNode1 {

  private SearchState state;

  // change from search1
  private SearchNode1 parent; // the parent node

  /**
   * constructor
   * 
   * @param s a SearchState
   */
  public SearchNode1(SearchState s) {
    state = (SearchState) s;
  }

  /**
   * accessor for state
   */
  public SearchState getState() {
    return state;
  }

  /**
   * accessor for parent
   */
  public SearchNode1 getParent() {
    return parent;
  }

  /**
   * mutator for parent
   */
  public void setParent(SearchNode1 n) {
    parent = n;
  }
  // must implement goalPredicate, getSuccessors, sameState, node_toString

  /**
   * goalPredicate takes a SearchNode1 & returns true if it's a goal
   * 
   * @param searcher the current search
   */
  public boolean goalPredicate(Search searcher) {
    return state.goalPredicate(searcher);
  }

  /**
   * getSuccessors for this node
   * 
   * @param searcher the current search
   * @return ArrayList of successor nodes
   */
  public ArrayList<SearchNode1> getSuccessors(Search1 searcher) {
    ArrayList<SearchState> slis = state.getSuccessors(searcher);
    ArrayList<SearchNode1> nlis = new ArrayList<SearchNode1>();

    for (SearchState suc_state : slis) {
      SearchNode1 n = new SearchNode1(suc_state);
      nlis.add(n);
    }
    return nlis;
  }

  /**
   * sameState - does another node have same state as this one?
   * 
   * @param n2 the other node
   */
  public boolean sameState(SearchNode1 n2) {
    return state.sameState(n2.getState());
  }

  public String toString() {
    return "has state " + state.toString();
  }

}
