import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
@SuppressWarnings("unused")
public class RunEpuzzleBFS {
	static final long MEGABYTE_FACTOR = 1024L * 1024L;
	public static void main(String[] args) {
		System.out.println("Starting bfs to solve 8-puzzle");
		
		//long start = System.currentTimeMillis();
		LocalDateTime startTime = LocalDateTime.now();
		EpuzzleSearch epuzzle = new EpuzzleSearch("1","2","5","3","4","0","6","7","8");
		boolean success = ((EpuzzleSearch) epuzzle).solve();
		LocalDateTime endTime = LocalDateTime.now();
		
		if(success)
		{
			System.out.println("\t\t\tStatistics:");
			System.out.println("Path to goal: " + epuzzle.getCurrentEpuzzleState().getPathToGoal());
			System.out.println("Cost to goal: " + epuzzle.getCurrentEpuzzleState().getCostOfPath());
			System.out.println("EpuzzleStates expanded: "+epuzzle.getExploredEpuzzleStates().size());
			System.out.println("Search depth: " + epuzzle.getCurrentEpuzzleState().getSearchDepth());
			System.out.println("Max Search depth: " + epuzzle.getCurrentEpuzzleState().getMaxSearchDepth());
			
			
			//long hours = startTime.until( endTime, ChronoUnit.HOURS);
			long seconds = startTime.until( endTime, ChronoUnit.SECONDS);
			if(seconds == 0)
			{
				long milliSeconds = startTime.until( endTime, ChronoUnit.MILLIS);
				System.out.println("running time:  "+ milliSeconds+" MILLISECONDS");
			}
			else
			{
				System.out.println("running time:  "+ seconds+" SECONDS");
			}
			@SuppressWarnings("unused")
			final long MEGABYTE_FACTOR = 1024L * 1024L; // declaring variable as a constant
			final DecimalFormat ROUNDED_DOUBLE_DECIMALFORMAT;// Constant 
			DecimalFormatSymbols otherSymbols = new DecimalFormatSymbols(Locale.ENGLISH);// constructor for DecimalFormat
		    otherSymbols.setDecimalSeparator('.');
		    otherSymbols.setGroupingSeparator(',');
		    ROUNDED_DOUBLE_DECIMALFORMAT = new DecimalFormat("####0.00", otherSymbols);// constructor for rounded double
		    ROUNDED_DOUBLE_DECIMALFORMAT.setGroupingUsed(false);
		    double totalMiB = bytesToMiB(getUsedMemory());
		    System.out.println(String.format("Max memory usage: %s Megabytes", totalMiB)); ;// print maximum memory usage
			
		}
		else
		{
			System.err.println("no solution found!");
		}
		

	}
	// accessor methods
	public static long getTotalMemory() {
	    return Runtime.getRuntime().totalMemory();
	}
	
	private static double bytesToMiB(long bytes) {
	    return ((double) bytes / MEGABYTE_FACTOR);
	}
	
	public static long getMaxMemory() {
	    return Runtime.getRuntime().maxMemory();
	}

	public static long getUsedMemory() {
	    return getTotalMemory() - getFreeMemory();
	}


	public static long getFreeMemory() {
	    return Runtime.getRuntime().freeMemory();
	}

}
