import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

@SuppressWarnings("unused")
public class EpuzzleSearch {
	Integer[][] initialState = new Integer[3][3];// initial state constructor
	EpuzzleState root;// initial state 
	EpuzzleState currentEpuzzleState;// current state
	Integer[][] goalState = {{0,1,2},{3,4,5},{6,7,8}}; //goal state
	Queue<EpuzzleState> fringe = new LinkedList<EpuzzleState>();// construct a new state
	List<EpuzzleState> exploredEpuzzleStates = new ArrayList<>(); //explore available states
	
	public EpuzzleSearch(String... state)//begin the search using recursion
	{
		int index = 0;
		for(int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				
				if(state[index].equals("0")) {// check if state is zero
					root = new EpuzzleState(0, i, j,initialState,"",0);// if yes initialize a new state
				}
				initialState[i][j] = Integer.parseInt(state[index++]); //increment the index of the state
				
			}
		}
		root.setState(initialState);// mutator method for initial state
	}
	
	public boolean solve()// test the solving procedure
	{
		boolean solved = false;// if not solved
		fringe.add(root); //add initial state
		
		while(!fringe.isEmpty())// fringe is not empty
		{
			
			currentEpuzzleState = fringe.poll();// call poll
			exploredEpuzzleStates.add(currentEpuzzleState);// add the current state
			if(goalReached())// when the goal is achieved
			{
				solved = true;// the puzzle is solved
				printCurrentState(); // print the current state
				return solved;
			}
			else // if the goal is not achieved
			{
				printCurrentState(); // print the current state
			}
			
			
			for(EpuzzleState neighbor : currentEpuzzleState.getNeighbors())//for every puzzle state get its corresponding neighbor
			{
				if(exploredEpuzzleStates.indexOf(neighbor) == -1 && fringe.contains(neighbor) == false)
				{
					fringe.add(neighbor); // add neighbor
					
				}
			}
			currentEpuzzleState.setNeighbors(null);// mutator method for neighbor
			
		}
		
		
		
		
		
		return solved; // return the solved results
	}

	private boolean goalReached() { //a method to test if the goal is reached
		boolean success = true;// if yes
		
		for(int i = 0; i < 3; i++)
		{
			for(int j = 0; j < 3; j++)
			{
				if(!currentEpuzzleState.getState()[i][j].equals(goalState[i][j]))//if the current puzzle state does not match to the goal state
				{
					success = false;// not successful
					break;// get out of the loop
				}
						
			}
			if(success == true)// if successful
			{
				break;// get out of the loop
			}
			
		}
		
		return success;// return success
	}

	private void printCurrentState() {// print the current state
		System.out.println("Current state after: " + currentEpuzzleState.getPathToGoal());
		for(int i = 0;i < 3; i++) // recursion
		{
			for(int j = 0; j < 3; j++)
			{
				System.out.print(currentEpuzzleState.getState()[i][j]+"");// get and print the current state
			}
			System.out.println("");
		}
		System.out.println("");
	}

	public Integer[][] getInitialState() {// get initial state
		return initialState; //return initial state
	}

	public void setInitialState(Integer[][] initialState) { // mutator method for initial state
		this.initialState = initialState;
	}

	public EpuzzleState getRoot() { // accessor method for original state
		return root;
	}

	public void setRoot(EpuzzleState root) {// mutator method for original state
		this.root = root;
	}

	public EpuzzleState getCurrentEpuzzleState() { // accessor method for current state
		return currentEpuzzleState;
	}

	public void setCurrentEpuzzleState(EpuzzleState currentEpuzzleState) {// mutator method for current state
		this.currentEpuzzleState = currentEpuzzleState;
	}

	public Integer[][] getGoalState() { // accessor method for goal state
		return goalState;
	}

	public void setGoalState(Integer[][] goalState) {// mutator method for goalstate
		this.goalState = goalState;
	}

	public Queue<EpuzzleState> getFringe() { // accessor method for Fringe
		return fringe;
	}

	public void setFringe(Queue<EpuzzleState> fringe) { //mutator method for Fringe
		this.fringe = fringe;
	}

	public List<EpuzzleState> getExploredEpuzzleStates() {// accessor method for ExploredEpuzzleStates
		return exploredEpuzzleStates;
	}

	public void setExploredEpuzzleStates(List<EpuzzleState> exploredEpuzzleStates) { // mutator method for ExploredEpuzzleStates
		this.exploredEpuzzleStates = exploredEpuzzleStates;
	}

	
	
	
}

