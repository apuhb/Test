import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
@SuppressWarnings("unused")
public class EpuzzleState {
	// variable initialization and declaration
	int i, j;
	Integer nodeVal;
	Integer[][] state = new Integer[3][3];
	List<EpuzzleState> neighbors = new ArrayList<>();
	String pathToGoal = "";
	Integer costOfPath = 0;
	int searchDepth = 0;
	int maxSearchDepth = 0;
	
	public EpuzzleState(Integer nodeVal, int i, int j, Integer[][] state, String pathToGoal,Integer costOfPath)
	// call the initialized values using 'this'
	{
		this.nodeVal = nodeVal;
		this.i = i;
		this.j = j;
		this.state = state;
		this.pathToGoal = pathToGoal;
		this.costOfPath = costOfPath;
		this.searchDepth = costOfPath;
	}
	
	
	// accessor method to access the neighbor to the right
	private void getRightNeighbor() {
		Integer[][] stateTemp = new Integer[3][3];
		for(int k = 0; k < 3; k++)
		{
			for(int l = 0; l < 3; l++)
			{
				stateTemp[k][l] = state[k][l];
			}
		}
		int i1 = i, j1 = j + 1;
		Integer nodeValTemp;
		if(j + 1 < 3)
		{
			nodeValTemp = stateTemp[i1][j1];
			Integer temp = stateTemp[i1][j1];
			stateTemp[i1][j1] = stateTemp[i][j];
			stateTemp[i][j] = temp;
			EpuzzleState tempNode = new EpuzzleState(nodeValTemp, i1, j1, stateTemp, pathToGoal+" Right", costOfPath+1);
			neighbors.add(tempNode);
		}
		
	}


// accessor method to get neighbor to the right
	private void getLeftNeighbor() {
		Integer[][] stateTemp = new Integer[3][3];
		for(int k = 0; k < 3; k++)
		{
			for(int l = 0; l < 3; l++)
			{
				stateTemp[k][l] = state[k][l];
			}
		}
		int i1 = i, j1 = j - 1;
		Integer nodeValTemp;
		if(j - 1 >= 0)
		{
			nodeValTemp = stateTemp[i1][j1];
			Integer temp = stateTemp[i1][j1];
			stateTemp[i1][j1] = stateTemp[i][j];
			stateTemp[i][j] = temp;
			EpuzzleState tempNode = new EpuzzleState(nodeValTemp, i1, j1, stateTemp, pathToGoal+" Left", costOfPath+1);
			neighbors.add(tempNode);
		}
		
	}


//accessor method to get the bottom neighbor
	private void getBottomNeighbor() {
		Integer[][] stateTemp = new Integer[3][3];
		for(int k = 0; k < 3; k++)
		{
			for(int l = 0; l < 3; l++)
			{
				stateTemp[k][l] = state[k][l];
			}
		}
		int i1 = i + 1, j1 = j;
		Integer nodeValTemp;
		if(i + 1 < 3)
		{
			nodeValTemp = stateTemp[i1][j1];
			Integer temp = stateTemp[i1][j1];
			stateTemp[i1][j1] = stateTemp[i][j];
			stateTemp[i][j] = temp;
			EpuzzleState tempNode = new EpuzzleState(nodeValTemp, i1, j1, stateTemp, pathToGoal+" Bottom", costOfPath+1);
			neighbors.add(tempNode);
		}
		
	}


// accessor method to get neighbor on top
	private void getTopNeighbor() {
		Integer[][] stateTemp = new Integer[3][3];
		for(int k = 0; k < 3; k++)
		{
			for(int l = 0; l < 3; l++)
			{
				stateTemp[k][l] = state[k][l];
			}
		}
		int i1 = i - 1, j1 = j;
		Integer nodeValTemp;
		if(i - 1 >= 0)
		{
			nodeValTemp = stateTemp[i1][j1];
			Integer temp = stateTemp[i1][j1];
			stateTemp[i1][j1] = stateTemp[i][j];
			stateTemp[i][j] = temp;
			EpuzzleState tempNode = new EpuzzleState(nodeValTemp, i1, j1, stateTemp, pathToGoal+" Top", costOfPath+1);
			neighbors.add(tempNode);
		}
		
		
		
	}



	public EpuzzleState() {
		super();// refer to the parent class 
	}



	public int getI() { // accessor method of I
		return i;
	}

	public void setI(int i) { // mutator method of I
		this.i = i;
	}

	public int getJ() { // accessor method of J
		return j;
	}

	public void setJ(int j) { // mutator method of J
		this.j = j;
	}

	public Integer getNodeVal() { // accessor method of NodeVal
		return nodeVal;
	}

	public void setNodeVal(Integer nodeVal) {// mutator method of NodeVal
		this.nodeVal = nodeVal;
	}

	public Integer[][] getState() { // accessor method of State
		return state;
	}

	public void setState(Integer[][] state) { // mutator method of State
		this.state = state;
	}



	public List<EpuzzleState> getNeighbors() { //get sate of each neighbor
		getTopNeighbor();
		getBottomNeighbor();
		getLeftNeighbor();
		getRightNeighbor();
		return neighbors;
	}



	public String getPathToGoal() { // accessor method of pathTo Goal
		return pathToGoal;
	}



	public void setPathToGoal(String pathToGoal) { // mutator method of pathTo Goal
		this.pathToGoal = pathToGoal;
	}



	public void setNeighbors(List<EpuzzleState> neighbors) { // mutator method of neighbors
		this.neighbors = neighbors;
	}



	@Override
	// inheriting attributes of the super class
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nodeVal == null) ? 0 : nodeVal.hashCode());
		return result;
	}



	@Override
	// inheriting attributes of the super class
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EpuzzleState other = (EpuzzleState) obj;
		if (nodeVal == null) {
			if (other.nodeVal != null)
				return false;
		} else if (!nodeVal.equals(other.nodeVal))
			return false;
		return true;
	}


// mutator and accessor methods 
	public Integer getCostOfPath() {
		return costOfPath;
	}



	public void setCostOfPath(Integer costOfPath) {
		this.costOfPath = costOfPath;
	}



	public int getSearchDepth() {
		return searchDepth;
	}



	public void setSearchDepth(int searchDepth) {
		this.searchDepth = searchDepth;
	}
	
	public int getMaxSearchDepth() {
		return searchDepth+1;
	}

	public void setMaxSearchDepth(int maxSearchDepth) {
		this.maxSearchDepth = maxSearchDepth;
	}
	
}
